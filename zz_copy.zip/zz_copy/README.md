# Assignment of PART II delivered by group 24
## Dependencies:
1. cd zz_copy
2. python == 3.7
3. pip install -r requirements.txt

## Training:
* Run `new2.py`

## Files:
* `custom_env3.py` Environment file. We made major changes to the Rewards.
* `models.py` Neural Network models.
* `new2.py` Training program. 
* `clip1.mp4` The rendering result. 